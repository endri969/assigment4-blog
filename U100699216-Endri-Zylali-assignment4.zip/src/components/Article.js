import React from 'react'

export default function Article() {
    return (
        <div>
            
        </div>
    )
}
